
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Locale;

import static org.junit.Assert.*;

import org.junit.Test;









public class CMDTest {

	@Test
	public void test01() throws NoSuchMethodException, SecurityException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, CMD.OptionException {
		CMD cmd = new CMD();
		System.out.println(cmd.addBooleanOption(""));
		System.out.println(cmd.addBooleanOption('a', "aaa"));
		Class optionClass = CMD.Option.class;
//		Constructor constructor = optionClass.getConstructor();
//		Object option =  constructor.newInstance();
//		System.out.println(cmd.getOptionValue(new Object()));
		CMD.Option booOption = cmd.addBooleanOption("");
		System.out.println(booOption.longForm());
		assertEquals(booOption.longForm(),"");
		System.out.println();
		assertFalse(booOption.wantsValue());
		
		CMD.Option option2 = cmd.addLongOption("long");
		option2.shortForm();
		CMD.Option option3 = cmd.addDoubleOption("123");
		CMD.Option option4 = cmd.addStringOption("string");
		CMD.Option option5 = cmd.addIntegerOption("integer");
		
		CMD.Option option6 = cmd.addLongOption('a',"long");
		CMD.Option option7 = cmd.addDoubleOption('b',"123");
		CMD.Option option8 = cmd.addStringOption('c',"string");
		CMD.Option option9 = cmd.addIntegerOption('d',"integer");
		
		System.out.println(cmd.getOptionValue(option2));
		assertEquals(cmd.getOptionValue(option2),null);
		System.out.println(option2.getValue("123", Locale.ENGLISH));
		assertEquals(option2.getValue("123", Locale.ENGLISH).toString(),"123");
		try {
			option2.getValue(null, Locale.ENGLISH);
		} catch (Exception e) {
			// TODO: handle exception
		}
		System.out.println(option3.getValue("123", Locale.ENGLISH));
		assertEquals(option2.getValue("123", Locale.ENGLISH).toString(),"123");
		System.out.println(booOption.getValue("123", Locale.ENGLISH));
		assertEquals(booOption.getValue("123", Locale.ENGLISH).toString(),"true");
		System.out.println(option4.getValue("123", Locale.ENGLISH));
		assertEquals(option4.getValue("123", Locale.ENGLISH).toString(),"123");
		System.out.println(option5.getValue("123", Locale.ENGLISH));
		assertEquals(option5.getValue("123", Locale.ENGLISH).toString(),"123");
		
		String[] strings = new String[4];
		strings[0] = "--long=1";
		strings[1] = "--string=2";
		strings[2] = "--ert=3";
		strings[3] = "--integer=4";
		System.out.println(cmd.getRemainingArgs());
		assertNull(cmd.getRemainingArgs());
		try {
			cmd.parse(strings);
		} catch (Exception e) {
			// TODO Auto-generated catch block
		}
		String[] strings1 = new String[1];
//		cmd.parse(strings1);
//		cmd.getRemainingArgs();
		System.out.println();
		System.out.println(cmd.getOptionValue(option2));
		assertEquals(cmd.getOptionValue(option2),null);
		cmd.getOptionValues(option2);
		assertEquals(cmd.getOptionValues(option2).toString(),"[]");
		System.out.println(cmd.getOptionValues(option2));
		
		try {
			option2.parseValue("123", Locale.ENGLISH);
		} catch (Exception e) {
			// TODO: handle exception
		}
		try {
			option3.parseValue("123", Locale.ENGLISH);
		} catch (Exception e) {
			// TODO: handle exception
		}
		try {
			option4.parseValue("123", Locale.ENGLISH);
		} catch (Exception e) {
			// TODO: handle exception
		}
		try {
			option5.parseValue("123", Locale.ENGLISH);
		} catch (Exception e) {
			// TODO: handle exception
		}
		booOption.parseValue("true", Locale.ENGLISH);
	}
}
