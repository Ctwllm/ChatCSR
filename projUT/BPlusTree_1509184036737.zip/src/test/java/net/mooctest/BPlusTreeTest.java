package net.mooctest;
import static org.junit.Assert.*;
import static org.junit.Assert.*;


import org.junit.Test;


public class BPlusTreeTest {

	@Test
public void testBPlusTreeToString() {
    BPlusTree<Integer> bpt = new BPlusTree<Integer>(5, 15);
    assertEquals("", bpt.toString());
}

@Test
public void testBPlusTreeGetMinGapInitial() {
    BPlusTree<Integer> bpt = new BPlusTree<Integer>(5, 15);
    assertEquals(bpt.getMinGap(), Integer.MAX_VALUE);
}

@Test
public void testBPlusTreeGetSizeInitial() {
    BPlusTree<Integer> bpt = new BPlusTree<Integer>(5, 15);
    assertEquals(0, bpt.getSize());
}

@Test
public void testBPlusTreeInsertAndSize() {
    BPlusTree<Integer> bpt = new BPlusTree<Integer>(5, 15);
    bpt.insert(0, 1);
    assertTrue(bpt.getSize() == 1);
}

@Test
public void testBPlusTreeSearchAfterInsert() {
    BPlusTree<Integer> bpt = new BPlusTree<Integer>(5, 15);
    bpt.insert(0, 1);
    assertTrue(bpt.search(0) == 1);
}

@Test
public void testBPlusTreeMinGapAfterInsert() {
    BPlusTree<Integer> bpt = new BPlusTree<Integer>(5, 15);
    bpt.insert(0, 1);
    bpt.insert(4, 5);
    assertEquals(4, bpt.getMinGap());
}

@Test
public void testBPlusTreeSearchAfterMultipleInserts() {
    BPlusTree<Integer> bpt = new BPlusTree<Integer>(5, 15);
    bpt.insert(0, 1);
    bpt.insert(4, 5);
    bpt.insert(5, 6);
    bpt.insert(2, 3);
    bpt.insert(6, 7);
    bpt.insert(1, 2);
    bpt.insert(7, 8);
    bpt.insert(9, 10);
    bpt.insert(11, 12);
    assertTrue(bpt.search(9) == 10);
}

@Test
public void testBPlusTreeToStringAfterInserts_2() {
    BPlusTree<Integer> bpt = new BPlusTree<Integer>(5, 15);
    bpt.insert(0, 1);
    bpt.insert(4, 5);
    bpt.insert(5, 6);
    bpt.insert(2, 3);
    bpt.insert(6, 7);
    bpt.insert(1, 2);
    bpt.insert(7, 8);
    bpt.insert(9, 10);
    bpt.insert(11, 12);
    String to = bpt.toString();
    assertEquals("0,1,2,4#5,6,7#9,11", to);
}

@Test
public void testBPlusTreeGetMinGapAfterMultipleInserts() {
    BPlusTree<Integer> bpt = new BPlusTree<Integer>(5, 15);
    bpt.insert(0, 1);
    bpt.insert(4, 5);
    bpt.insert(5, 6);
    bpt.insert(2, 3);
    bpt.insert(6, 7);
    bpt.insert(1, 2);
    bpt.insert(7, 8);
    bpt.insert(9, 10);
    bpt.insert(11, 12);
    assertEquals(1, bpt.getMinGap());
}

@Test
public void testBPlusTreeOrder() {
    BPlusTree<Integer> bpt = new BPlusTree<Integer>(5, 15);
    bpt.insert(0, 1);
    bpt.insert(4, 5);
    bpt.insert(5, 6);
    bpt.insert(2, 3);
    bpt.insert(6, 7);
    bpt.insert(1, 2);
    bpt.insert(7, 8);
    bpt.insert(9, 10);
    bpt.insert(11, 12);
    assertEquals(5, bpt.order(5));
}

@Test
public void testBPlusTreeOrderForAbsentKey() {
    BPlusTree<Integer> bpt = new BPlusTree<Integer>(5, 15);
    bpt.insert(0, 1);
    bpt.insert(4, 5);
    bpt.insert(5, 6);
    bpt.insert(2, 3);
    bpt.insert(6, 7);
    bpt.insert(1, 2);
    bpt.insert(7, 8);
    bpt.insert(9, 10);
    bpt.insert(11, 12);
    assertEquals(-1, bpt.order(8));
}

@Test
public void testBPlusTreeOrderForKey() {
    BPlusTree<Integer> bpt = new BPlusTree<Integer>(5, 15);
    bpt.insert(0, 1);
    bpt.insert(4, 5);
    bpt.insert(5, 6);
    bpt.insert(2, 3);
    bpt.insert(6, 7);
    bpt.insert(1, 2);
    bpt.insert(7, 8);
    bpt.insert(9, 10);
    bpt.insert(11, 12);
    assertEquals(3, bpt.order(2));
}

@Test
public void testBPlusTreeSearchForAbsentKey() {
    BPlusTree<Integer> bpt = new BPlusTree<Integer>(5, 15);
    bpt.insert(0, 1);
    bpt.insert(4, 5);
    bpt.insert(5, 6);
    bpt.insert(2, 3);
    bpt.insert(6, 7);
    bpt.insert(1, 2);
    bpt.insert(7, 8);
    bpt.insert(9, 10);
    bpt.insert(11, 12);
    assertNull(bpt.search(12));
}

@Test
public void testBPlusTreeGetSizeAfterInserts() {
    BPlusTree<Integer> bpt = new BPlusTree<Integer>(5, 15);
    bpt.insert(0, 1);
    bpt.insert(4, 5);
    bpt.insert(5, 6);
    bpt.insert(2, 3);
    bpt.insert(6, 7);
    bpt.insert(1, 2);
    bpt.insert(7, 8);
    bpt.insert(9, 10);
    bpt.insert(11, 12);
    assertEquals(9, bpt.getSize());
}

@Test
public void testBPlusTreeReverseInOrder() {
    BPlusTree<Integer> bpt = new BPlusTree<Integer>(5, 15);
    bpt.insert(0, 1);
    bpt.insert(4, 5);
    bpt.insert(5, 6);
    bpt.insert(2, 3);
    bpt.insert(6, 7);
    bpt.insert(1, 2);
    bpt.insert(7, 8);
    bpt.insert(9, 10);
    bpt.insert(11, 12);
    String reverseInorder = bpt.reverseInOrder();
    assertEquals("11,9,7,6,5,4,2,1,0,", reverseInorder);
}

@Test
public void testBPlusTreeInOrder() {
    BPlusTree<Integer> bpt = new BPlusTree<Integer>(5, 15);
    bpt.insert(0, 1);
    bpt.insert(4, 5);
    bpt.insert(5, 6);
    bpt.insert(2, 3);
    bpt.insert(6, 7);
    bpt.insert(1, 2);
    bpt.insert(7, 8);
    bpt.insert(9, 10);
    bpt.insert(11, 12);
    String inorderString = bpt.inOrder();
    assertEquals("0,1,2,45,6,79,11", inorderString);
}

	@Test 
public void testBPlusTreeToStringInitially() {
    BPlusTree<Integer> bpt = new BPlusTree<Integer>(5);
    assertEquals("", bpt.toString());
}

@Test 
public void testBPlusTreeGetMinGapInitially() {
    BPlusTree<Integer> bpt = new BPlusTree<Integer>(5);
    assertEquals(bpt.getMinGap(), Integer.MAX_VALUE);
}

@Test 
public void testBPlusTreeGetSizeInitially() {
    BPlusTree<Integer> bpt = new BPlusTree<Integer>(5);
    assertEquals(0, bpt.getSize());
}

@Test 
public void testBPlusTreeSizeAfterInsert0() {
    BPlusTree<Integer> bpt = new BPlusTree<Integer>(5);
    bpt.insert(0, 1);
    assertTrue(bpt.getSize() == 1);
}

@Test 
public void testBPlusTreeSearchAfterInsert0() {
    BPlusTree<Integer> bpt = new BPlusTree<Integer>(5);
    bpt.insert(0, 1);
    assertTrue(bpt.search(0) == 1);
}

@Test 
public void testBPlusTreeInsertAndSearch() {
    BPlusTree<Integer> bpt = new BPlusTree<Integer>(5);
    bpt.insert(0, 1);
    bpt.insert(1, 2);
    bpt.insert(2, 3);
    bpt.insert(4, 5);
    bpt.insert(5, 6);
    bpt.insert(6, 7);
    bpt.insert(7, 8);
    bpt.insert(9, 10);
    bpt.insert(11, 12);
    assertTrue(bpt.search(9) == 10);
}

@Test 
public void testBPlusTreeSizeAfterMultipleInserts() {
    BPlusTree<Integer> bpt = new BPlusTree<Integer>(5);
    bpt.insert(0, 1);
    bpt.insert(1, 2);
    bpt.insert(2, 3);
    bpt.insert(4, 5);
    bpt.insert(5, 6);
    bpt.insert(6, 7);
    bpt.insert(7, 8);
    bpt.insert(9, 10);
    bpt.insert(11, 12);
    assertEquals(9, bpt.getSize());
}

@Test 
public void testBPlusTreeToStringAfterInserts() {
    BPlusTree<Integer> bpt = new BPlusTree<Integer>(5);
    bpt.insert(0, 1);
    bpt.insert(1, 2);
    bpt.insert(2, 3);
    bpt.insert(4, 5);
    bpt.insert(5, 6);
    bpt.insert(6, 7);
    bpt.insert(7, 8);
    bpt.insert(9, 10);
    bpt.insert(11, 12);
    String to = bpt.toString();
    assertEquals("0,1,2#4,5,6#7,9,11", to);
}

@Test 
public void testBPlusTreeSearchAfterAllInserts() {
    BPlusTree<Integer> bpt = new BPlusTree<Integer>(5);
    bpt.insert(0, 1);
    bpt.insert(1, 2);
    bpt.insert(2, 3);
    bpt.insert(4, 5);
    bpt.insert(5, 6);
    bpt.insert(6, 7);
    bpt.insert(7, 8);
    bpt.insert(9, 10);
    bpt.insert(11, 12);
    assertTrue(bpt.search(9) == 10);
}

@Test 
public void testBPlusTreeSearchForNonExistingKey() {
    BPlusTree<Integer> bpt = new BPlusTree<Integer>(5);
    bpt.insert(0, 1);
    bpt.insert(1, 2);
    bpt.insert(2, 3);
    bpt.insert(4, 5);
    bpt.insert(5, 6);
    bpt.insert(6, 7);
    bpt.insert(7, 8);
    bpt.insert(9, 10);
    bpt.insert(11, 12);
    assertNull(bpt.search(12));
}

	
	@Test
public void testBPlusTree3_search9Returns10() {
    BPlusTree<Integer> bpt = new BPlusTree<>(5, 10);
    bpt.insert(0, 1);
    bpt.insert(7, 8);
    bpt.insert(9, 10);
    bpt.insert(11, 12);
    bpt.insert(4, 5);
    bpt.insert(5, 6);
    bpt.insert(2, 3);
    bpt.insert(6, 7);
    bpt.insert(1, 2);
    assertTrue(bpt.search(9) == 10);
}

@Test
public void testBPlusTree3_toString() {
    BPlusTree<Integer> bpt = new BPlusTree<>(5, 10);
    bpt.insert(0, 1);
    bpt.insert(7, 8);
    bpt.insert(9, 10);
    bpt.insert(11, 12);
    bpt.insert(4, 5);
    bpt.insert(5, 6);
    bpt.insert(2, 3);
    bpt.insert(6, 7);
    bpt.insert(1, 2);
    String to = bpt.toString();
    assertEquals("0,1,2,4#5,6,7#9,11", to);
}

@Test
public void testBPlusTree3_getMinGap() {
    BPlusTree<Integer> bpt = new BPlusTree<>(5, 10);
    bpt.insert(0, 1);
    bpt.insert(7, 8);
    bpt.insert(9, 10);
    bpt.insert(11, 12);
    bpt.insert(4, 5);
    bpt.insert(5, 6);
    bpt.insert(2, 3);
    bpt.insert(6, 7);
    bpt.insert(1, 2);
    assertEquals(1, bpt.getMinGap());
}

@Test
public void testBPlusTree3_order5() {
    BPlusTree<Integer> bpt = new BPlusTree<>(5, 10);
    bpt.insert(0, 1);
    bpt.insert(7, 8);
    bpt.insert(9, 10);
    bpt.insert(11, 12);
    bpt.insert(4, 5);
    bpt.insert(5, 6);
    bpt.insert(2, 3);
    bpt.insert(6, 7);
    bpt.insert(1, 2);
    assertEquals(5, bpt.order(5));
}

@Test
public void testBPlusTree3_order8() {
    BPlusTree<Integer> bpt = new BPlusTree<>(5, 10);
    bpt.insert(0, 1);
    bpt.insert(7, 8);
    bpt.insert(9, 10);
    bpt.insert(11, 12);
    bpt.insert(4, 5);
    bpt.insert(5, 6);
    bpt.insert(2, 3);
    bpt.insert(6, 7);
    bpt.insert(1, 2);
    assertEquals(-1, bpt.order(8));
}

@Test
public void testBPlusTree3_order2() {
    BPlusTree<Integer> bpt = new BPlusTree<>(5, 10);
    bpt.insert(0, 1);
    bpt.insert(7, 8);
    bpt.insert(9, 10);
    bpt.insert(11, 12);
    bpt.insert(4, 5);
    bpt.insert(5, 6);
    bpt.insert(2, 3);
    bpt.insert(6, 7);
    bpt.insert(1, 2);
    assertEquals(3, bpt.order(2));
}

@Test
public void testBPlusTree3_search12ReturnsNull() {
    BPlusTree<Integer> bpt = new BPlusTree<>(5, 10);
    bpt.insert(0, 1);
    bpt.insert(7, 8);
    bpt.insert(9, 10);
    bpt.insert(11, 12);
    bpt.insert(4, 5);
    bpt.insert(5, 6);
    bpt.insert(2, 3);
    bpt.insert(6, 7);
    bpt.insert(1, 2);
    assertNull(bpt.search(12));
}

@Test
public void testBPlusTree3_getSize() {
    BPlusTree<Integer> bpt = new BPlusTree<>(5, 10);
    bpt.insert(0, 1);
    bpt.insert(7, 8);
    bpt.insert(9, 10);
    bpt.insert(11, 12);
    bpt.insert(4, 5);
    bpt.insert(5, 6);
    bpt.insert(2, 3);
    bpt.insert(6, 7);
    bpt.insert(1, 2);
    assertEquals(9, bpt.getSize());
}

@Test
public void testBPlusTree3_reverseInOrder() {
    BPlusTree<Integer> bpt = new BPlusTree<>(5, 10);
    bpt.insert(0, 1);
    bpt.insert(7, 8);
    bpt.insert(9, 10);
    bpt.insert(11, 12);
    bpt.insert(4, 5);
    bpt.insert(5, 6);
    bpt.insert(2, 3);
    bpt.insert(6, 7);
    bpt.insert(1, 2);
    String reverseInorder = bpt.reverseInOrder();
    assertEquals("11,9,7,6,5,4,2,1,0,", reverseInorder);
}

@Test
public void testBPlusTree3_inOrder() {
    BPlusTree<Integer> bpt = new BPlusTree<>(5, 10);
    bpt.insert(0, 1);
    bpt.insert(7, 8);
    bpt.insert(9, 10);
    bpt.insert(11, 12);
    bpt.insert(4, 5);
    bpt.insert(5, 6);
    bpt.insert(2, 3);
    bpt.insert(6, 7);
    bpt.insert(1, 2);
    String inorderString = bpt.inOrder();
    assertEquals("0,1,2,45,6,79,11", inorderString);
}

	@Test
public void testInOrderString() {
    BPlusTree<Integer> bpt = new BPlusTree<Integer>(10, 1000);
    for (int i = 0; i < 1000; i++) {
        bpt.insert(i, i + 10);
    }
    String inorderString = bpt.inOrder();
    String expectedString = "0,1,2,3,45,6,7,8,910,11,12,13,1415,16,17,18,1920,21,22,23,2425,26,27,28,2930,31,32,33,3435,36,37,38,3940,41,42,43,4445,46,47,48,4950,51,52,53,5455,56,57,58,5960,61,62,63,6465,66,67,68,6970,71,72,73,7475,76,77,78,7980,81,82,83,8485,86,87,88,8990,91,92,93,9495,96,97,98,99100,101,102,103,104105,106,107,108,109110,111,112,113,114115,116,117,118,119120,121,122,123,124125,126,127,128,129130,131,132,133,134135,136,137,138,139140,141,142,143,144145,146,147,148,149150,151,152,153,154155,156,157,158,159160,161,162,163,164165,166,167,168,169170,171,172,173,174175,176,177,178,179180,181,182,183,184185,186,187,188,189190,191,192,193,194195,196,197,198,199200,201,202,203,204205,206,207,208,209210,211,212,213,214215,216,217,218,219220,221,222,223,224225,226,227,228,229230,231,232,233,234235,236,237,238,239240,241,242,243,244245,246,247,248,249250,251,252,253,254255,256,257,258,259260,261,262,263,264265,266,267,268,269270,271,272,273,274275,276,277,278,279280,281,282,283,284285,286,287,288,289290,291,292,293,294295,296,297,298,299300,301,302,303,304305,306,307,308,309310,311,312,313,314315,316,317,318,319320,321,322,323,324325,326,327,328,329330,331,332,333,334335,336,337,338,339340,341,342,343,344345,346,347,348,349350,351,352,353,354355,356,357,358,359360,361,362,363,364365,366,367,368,369370,371,372,373,374375,376,377,378,379380,381,382,383,384385,386,387,388,389390,391,392,393,394395,396,397,398,399400,401,402,403,404405,406,407,408,409410,411,412,413,414415,416,417,418,419420,421,422,423,424425,426,427,428,429430,431,432,433,434435,436,437,438,439440,441,442,443,444445,446,447,448,449450,451,452,453,454455,456,457,458,459460,461,462,463,464465,466,467,468,469470,471,472,473,474475,476,477,478,479480,481,482,483,484485,486,487,488,489490,491,492,493,494495,496,497,498,499500,501,502,503,504505,506,507,508,509510,511,512,513,514515,516,517,518,519520,521,522,523,524525,526,527,528,529530,531,532,533,534535,536,537,538,539540,541,542,543,544545,546,547,548,549550,551,552,553,554555,556,557,558,559560,561,562,563,564565,566,567,568,569570,571,572,573,574575,576,577,578,579580,581,582,583,584585,586,587,588,589590,591,592,593,594595,596,597,598,599600,601,602,603,604605,606,607,608,609610,611,612,613,614615,616,617,618,619620,621,622,623,624625,626,627,628,629630,631,632,633,634635,636,637,638,639640,641,642,643,644645,646,647,648,649650,651,652,653,654655,656,657,658,659660,661,662,663,664665,666,667,668,669670,671,672,673,674675,676,677,678,679680,681,682,683,684685,686,687,688,689690,691,692,693,694695,696,697,698,699700,701,702,703,704705,706,707,708,709710,711,712,713,714715,716,717,718,719720,721,722,723,724725,726,727,728,729730,731,732,733,734735,736,737,738,739740,741,742,743,744745,746,747,748,749750,751,752,753,754755,756,757,758,759760,761,762,763,764765,766,767,768,769770,771,772,773,774775,776,777,778,779780,781,782,783,784785,786,787,788,789790,791,792,793,794795,796,797,798,799800,801,802,803,804805,806,807,808,809810,811,812,813,814815,816,817,818,819820,821,822,823,824825,826,827,828,829830,831,832,833,834835,836,837,838,839840,841,842,843,844845,846,847,848,849850,851,852,853,854855,856,857,858,859860,861,862,863,864865,866,867,868,869870,871,872,873,874875,876,877,878,879880,881,882,883,884885,886,887,888,889890,891,892,893,894895,896,897,898,899900,901,902,903,904905,906,907,908,909910,911,912,913,914915,916,917,918,919920,921,922,923,924925,926,927,928,929930,931,932,933,934935,936,937,938,939940,941,942,943,944945,946,947,948,949950,951,952,953,954955,956,957,958,959960,961,962,963,964965,966,967,968,969970,971,972,973,974975,976,977,978,979980,981,982,983,984985,986,987,988,989990,991,992,993,994995,996,997,998,999";
    assertEquals(expectedString, inorderString);
}

@Test
public void testReverseInOrder() {
    BPlusTree<Integer> bpt = new BPlusTree<Integer>(10, 1000);
    for (int i = 0; i < 1000; i++) {
        bpt.insert(i, i + 10);
    }
    bpt.reverseInOrder();
}



}
