package net.mooctest;
import static org.junit.Assert.*;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Locale;

import static org.junit.Assert.*;

import org.junit.Test;









public class CMDTest {

	@Test
public void testAddBooleanOptionLongForm() throws NoSuchMethodException, SecurityException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, CMD.OptionException {
    CMD cmd = new CMD();
    CMD.Option booOption = cmd.addBooleanOption("");
    assertEquals(booOption.longForm(), "");
}

@Test
public void testAddBooleanOptionWantsValue() throws NoSuchMethodException, SecurityException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, CMD.OptionException {
    CMD cmd = new CMD();
    CMD.Option booOption = cmd.addBooleanOption("");
    assertFalse(booOption.wantsValue());
}

@Test
public void testGetOptionValueNull() throws NoSuchMethodException, SecurityException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, CMD.OptionException {
    CMD cmd = new CMD();
    CMD.Option option2 = cmd.addLongOption("long");
    assertEquals(cmd.getOptionValue(option2), null);
}

@Test
public void testOptionValue123() throws NoSuchMethodException, SecurityException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, CMD.OptionException {
    CMD cmd = new CMD();
    CMD.Option option2 = cmd.addLongOption("long");
    assertEquals(option2.getValue("123", Locale.ENGLISH).toString(), "123");
}

@Test
public void testBooleanOptionValue123() throws NoSuchMethodException, SecurityException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, CMD.OptionException {
    CMD cmd = new CMD();
    CMD.Option booOption = cmd.addBooleanOption("");
    assertEquals(booOption.getValue("123", Locale.ENGLISH).toString(), "true");
}

@Test
public void testOption4Value123() throws NoSuchMethodException, SecurityException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, CMD.OptionException {
    CMD cmd = new CMD();
    CMD.Option option4 = cmd.addStringOption("string");
    assertEquals(option4.getValue("123", Locale.ENGLISH).toString(), "123");
}

@Test
public void testOption5Value123() throws NoSuchMethodException, SecurityException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, CMD.OptionException {
    CMD cmd = new CMD();
    CMD.Option option5 = cmd.addIntegerOption("integer");
    assertEquals(option5.getValue("123", Locale.ENGLISH).toString(), "123");
}

@Test
public void testGetRemainingArgsNull() throws NoSuchMethodException, SecurityException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, CMD.OptionException {
    CMD cmd = new CMD();
    String[] strings = new String[4];
    strings[0] = "--long=1";
    strings[1] = "--string=2";
    strings[2] = "--ert=3";
    strings[3] = "--integer=4";
    assertNull(cmd.getRemainingArgs());
}

//@Test
//public void testOption2ValuesEmpty() throws NoSuchMethodException, SecurityException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, CMD.OptionException {
//    CMD cmd = new CMD();
//    CMD.Option option2 = cmd.addLongOption("long");
//    String[] strings = new String[4];
//    strings[0] = "--long=1";
//    strings[1] = "--string=2";
//    strings[2] = "--ert=3";
//    strings[3] = "--integer=4";
//    cmd.parse(strings);
//    assertEquals(cmd.getOptionValues(option2).toString(), "[]");
//}

}
