package net.mooctest;
import static org.junit.Assert.*;
import static org.junit.Assert.*;

import org.junit.Test;


public class IntegerBloomFilterTest {

	@Test
public void testContains40() {
    IntegerBloomFilter inFilter = new IntegerBloomFilter(0.000001, 10);
    inFilter.add(40);
    assertTrue(inFilter.contains(40));
}

@Test
public void testDoesNotContain50() {
    IntegerBloomFilter inFilter = new IntegerBloomFilter(0.000001, 10);
    inFilter.add(40);
    assertFalse(inFilter.contains(50));
}

@Test
public void testBitsPerElement() {
    IntegerBloomFilter inFilter = new IntegerBloomFilter(0.000001, 10);
    assertEquals(29, inFilter.getBitsPerElement());
}

@Test
public void testFilterSize() {
    IntegerBloomFilter inFilter = new IntegerBloomFilter(0.000001, 10);
    assertEquals(290, inFilter.getFilterSize());
}

@Test
public void testTotalHashFunctions() {
    IntegerBloomFilter inFilter = new IntegerBloomFilter(0.000001, 10);
    assertEquals(20, inFilter.getTotalHashFunctions());
}

@Test
public void testClear() {
    IntegerBloomFilter inFilter = new IntegerBloomFilter(0.000001, 10);
    inFilter.add(40);
    inFilter.clear();
    assertFalse(inFilter.contains(40));
}

	@Test
public void test2_getExpectedFalsePositiveProbability() {
    IntegerBloomFilter inFilter = new IntegerBloomFilter(0.000001, 10);
    double efpp = inFilter.getExpectedFalsePositiveProbability();
    assertTrue(efpp == 8.89124548750276E-7);
}

@Test
public void test2_getCurrentFalsePositiveProbability() {
    IntegerBloomFilter inFilter = new IntegerBloomFilter(0.000001, 10);
    inFilter.add(40);
    double cfpp = inFilter.getCurrentFalsePositiveProbability();
    assertTrue(cfpp == 2.984336515583906E-24);
}


}
