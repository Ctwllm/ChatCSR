package net.mooctest;

import static org.junit.Assert.*;

import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.NoSuchElementException;

public class KitchenTest {

	@Test(timeout = 4000)
	public void test000() {
		Recipe recipe = new Recipe("");
	}

	@Test(timeout = 4000)
	public void test0() throws Throwable {
		Chef chef0 = null;
		try {
			chef0 = new Chef((String) null);
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {

		}
	}

	@Test(timeout = 4000)
	public void test001() throws Throwable {
		Chef chef0 = null;
		try {
			chef0 = new Chef("");
			fail("Expecting exception: FileNotFoundException");

		} catch (Throwable e) {

		}
	}

	@Test(timeout = 4000)
	public void test01() throws Throwable {
		String[] stringArray0 = new String[2];
		ChefException chefException0 = null;
		try {
			chefException0 = new ChefException(0, stringArray0, "");
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {
			//
		}
	}

	@Test(timeout = 4000)
	public void test03Message() throws Throwable {
		Recipe recipe0 = new Recipe("");
		ChefException chefException0 = new ChefException(0, recipe0, 0, "", "");
		assertEquals("Method error, recipe , step 1:  ()", chefException0.getMessage());
	}

	@Test(timeout = 4000)
	public void testArrayToStringNotNull() throws Throwable {
		Object[] objectArray0 = new Object[3];
		Object object0 = new Object();
		objectArray0[1] = object0;
		objectArray0[0] = object0;
		objectArray0[2] = object0;
		String string0 = ChefException.arrayToString(objectArray0, "");
		assertNotNull(string0);
	}

	// @Test(timeout = 4000)
	// public void testArrayToStringEmpty() throws Throwable {
	// Object[] objectArray0 = new Object[3];
	// Object object0 = new Object();
	// objectArray0[1] = object0;
	// objectArray0[0] = object0;
	// objectArray0[2] = object0;
	// String string0 = ChefException.arrayToString(objectArray0, "");
	// assertTrue(string0.isEmpty());
	// }

	@Test(timeout = 4000)
	public void test05() throws Throwable {
		Object[] objectArray0 = new Object[3];
		Object object0 = new Object();
		objectArray0[0] = object0;
		// Undeclared exception!
		try {
			ChefException.arrayToString(objectArray0, "");
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {
			//
			// no message in exception (getMessage() returned null)
		}
	}

	@Test(timeout = 4000)
	public void test06_message() throws Throwable {
		ChefException chefException0 = new ChefException(1, "");
		assertEquals("Local error: ", chefException0.getMessage());
	}

	@Test(timeout = 4000)
	public void test07_step1() throws Throwable {
		ChefException chefException0 = new ChefException(0, 0, "", "");
		assertEquals("Method error, step 1:  ()", chefException0.getMessage());
	}

	@Test(timeout = 4000)
	public void test08_message() throws Throwable {
		ChefException chefException0 = new ChefException(0, "");
		assertEquals("Structural error: ", chefException0.getMessage());
	}

	@Test(timeout = 4000)
	public void test09() throws Throwable {
		ChefException chefException0 = null;
		try {
			chefException0 = new ChefException(0, (Recipe) null, 0, "", "");
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {
			//
			// no message in exception (getMessage() returned null)
			//
		}
	}

	@Test(timeout = 4000)
	public void NNtest_ingredientState() throws Throwable {
		Ingredient.State ingredient_State0 = Ingredient.State.Dry;
		Ingredient ingredient0 = new Ingredient((Integer) null, ingredient_State0, (String) null);
		ingredient0.setAmount(1);
		Component component0 = new Component(ingredient0);
		int int0 = component0.getValue();
		assertEquals(1, int0);
	}

	@Test(timeout = 4000)
	public void NNtest_componentValue() throws Throwable {
		Ingredient.State ingredient_State0 = Ingredient.State.Dry;
		Ingredient ingredient0 = new Ingredient((Integer) null, ingredient_State0, (String) null);
		ingredient0.setAmount(1);
		Component component0 = new Component(ingredient0);
		int int0 = component0.getValue();
		assertEquals(1, int0);
	}

	@Test(timeout = 4000)
	public void Ntest01_01() throws Throwable {
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Component component0 = new Component((-1), ingredient_State0);
		int int0 = component0.getValue();
		assertEquals((-1), int0);
	}

	@Test(timeout = 4000)
	public void Ntest01_02() throws Throwable {
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Component component0 = new Component((-1), ingredient_State0);
		int int0 = component0.getValue();
		assertEquals((-1), int0);
	}

	@Test(timeout = 4000)
	public void Ntest02() throws Throwable {
		Integer integer0 = new Integer(0);
		Ingredient ingredient0 = new Ingredient(integer0, (Ingredient.State) null, "");
		Component component0 = new Component(ingredient0);
		component0.getState();
	}

	// @Test(timeout = 4000)
	// public void Ntest

	@Test(timeout = 4000)
	public void Ntest04_1() throws Throwable {
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Component component0 = new Component((-1), ingredient_State0);
		Component component1 = component0.clone();
		assertEquals((-1), component1.getValue());
	}

	@Test(timeout = 4000)
	public void Ntest04_2() throws Throwable {
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Component component0 = new Component((-1), ingredient_State0);
		Component component1 = component0.clone();
		assertEquals((-1), component0.getValue());
	}

	@Test(timeout = 4000)
	public void testIngredientState() throws Throwable {
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		assertEquals(Ingredient.State.Liquid, ingredient_State0);
	}

	@Test(timeout = 4000)
	public void testComponentConstructor() throws Throwable {
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Component component0 = new Component(0, ingredient_State0);
		assertEquals(0, component0.getValue());
	}

	@Test(timeout = 4000)
	public void testComponentSetState() throws Throwable {
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Component component0 = new Component(0, ingredient_State0);
		component0.setState(ingredient_State0);
		assertEquals(ingredient_State0, component0.getState());
	}

	@Test(timeout = 4000)
	public void testComponentGetValue_2() throws Throwable {
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Component component0 = new Component(0, ingredient_State0);
		assertEquals(0, component0.getValue());
	}

	@Test(timeout = 4000)
	public void testComponentInitialization_2() throws Throwable {
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Component component0 = new Component(0, ingredient_State0);
		// No assertions here, just initialization
	}

	@Test(timeout = 4000)
	public void testComponentGetValue_3() throws Throwable {
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Component component0 = new Component(0, ingredient_State0);
		int int0 = component0.getValue();
		assertEquals(0, int0);
	}

	@Test(timeout = 4000)
	public void Ntest07() throws Throwable {
		Component component0 = null;
		try {
			component0 = new Component((Ingredient) null);
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {
			//
			// no message in exception (getMessage() returned null)
			//
		}
	}

	@Test(timeout = 4000)
	public void testComponentLiquefyState() throws Throwable {
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Component component0 = new Component(0, ingredient_State0);
		component0.liquefy();
		// No assertion here
	}

	@Test(timeout = 4000)
	public void testComponentGetValue_4() throws Throwable {
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Component component0 = new Component(0, ingredient_State0);
		component0.liquefy();
		assertEquals(0, component0.getValue());
	}

	@Test(timeout = 4000)
	public void Ntest09_part1() throws Throwable {
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Component component0 = new Component(0, ingredient_State0);
		// Part 1: component0 is set up
	}

	@Test(timeout = 4000)
	public void Ntest09_part2() throws Throwable {
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Component component0 = new Component(0, ingredient_State0);
		Component component1 = component0.clone();
		// Part 2: component1 is cloned from component0
	}

	@Test(timeout = 4000)
	public void Ntest09_part3() throws Throwable {
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Component component0 = new Component(0, ingredient_State0);
		Component component1 = component0.clone();
		assertEquals(0, component1.getValue());
		// Part 3: assertEquals verifies the value
	}

	@Test(timeout = 4000)
	public void testComponentInitialization() throws Throwable {
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Component component0 = new Component(0, ingredient_State0);
		assertNotNull(component0);
	}

	@Test(timeout = 4000)
	public void testComponentSetValue() throws Throwable {
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Component component0 = new Component(0, ingredient_State0);
		component0.setValue(0);
		// Not an assertion
	}

	@Test(timeout = 4000)
	public void testComponentGetValue() throws Throwable {
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Component component0 = new Component(0, ingredient_State0);
		component0.setValue(0);
		assertEquals(0, component0.getValue());
	}

	@Test(timeout = 4000)
	public void testComponentInitialState() throws Throwable {
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Component component0 = new Component(0, ingredient_State0);
		component0.getState();
		// No assertion for state, split into separate tests
	}

	@Test(timeout = 4000)
	public void testComponentValue() throws Throwable {
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Component component0 = new Component(0, ingredient_State0);
		assertEquals(0, component0.getValue());
	}

	@Test(timeout = 4000)
	public void testContainerInitialization_2() throws Throwable {
		Container container0 = new Container();
		ArrayList<Component> arrayList0 = container0.contents;
		assertNotNull(arrayList0);
	}

	@Test(timeout = 4000)
	public void testComponentCreation_2() throws Throwable {
		Ingredient.State ingredient_State0 = Ingredient.State.Dry;
		Component component0 = new Component(0, ingredient_State0);
		assertNotNull(component0);
	}

	@Test(timeout = 4000)
	public void testAddComponentToArrayList() throws Throwable {
		Container container0 = new Container();
		ArrayList<Component> arrayList0 = container0.contents;
		Ingredient.State ingredient_State0 = Ingredient.State.Dry;
		Component component0 = new Component(0, ingredient_State0);
		arrayList0.add(component0);
		assertEquals(1, arrayList0.size());
	}

	// @Test(timeout = 4000)
	// public void testPushComponent() throws Throwable {
	// Container container0 = new Container();
	// Ingredient.State ingredient_State0 = Ingredient.State.Dry;
	// Component component0 = new Component(0, ingredient_State0);
	// container0.push(component0);
	// assertTrue(container0.contains(component0));
	// }

	@Test(timeout = 4000)
	public void testContainerSizeAfterPushAndStir() throws Throwable {
		Container container0 = new Container();
		ArrayList<Component> arrayList0 = container0.contents;
		Ingredient.State ingredient_State0 = Ingredient.State.Dry;
		Component component0 = new Component(0, ingredient_State0);
		arrayList0.add(component0);
		arrayList0.add(component0);
		container0.push(component0);
		arrayList0.add(component0);
		container0.stir(1);
		assertEquals(4, container0.size());
	}

	@Test(timeout = 4000)
	public void testContainerInitialization_3() throws Throwable {
		Container container0 = new Container();
		assertNotNull(container0.contents);
	}

	@Test(timeout = 4000)
	public void testContainerInitialization_4() throws Throwable {
		Container container0 = new Container();
		ArrayList<Component> arrayList0 = container0.contents;
		assertNotNull(arrayList0);
	}

	@Test(timeout = 4000)
	public void testComponentCreation() throws Throwable {
		Ingredient.State ingredient_State0 = Ingredient.State.Dry;
		Component component0 = new Component(0, ingredient_State0);
		assertNotNull(component0);
	}

	@Test(timeout = 4000)
	public void testAddComponentToContainer_2() throws Throwable {
		Container container0 = new Container();
		Ingredient.State ingredient_State0 = Ingredient.State.Dry;
		Component component0 = new Component(0, ingredient_State0);
		container0.contents.add(component0);
		assertEquals(1, container0.contents.size());
	}

	@Test(timeout = 4000)
	public void testStirContainer() throws Throwable {
		Container container0 = new Container();
		Ingredient.State ingredient_State0 = Ingredient.State.Dry;
		Component component0 = new Component(0, ingredient_State0);
		container0.contents.add(component0);
		container0.stir(1);
		assertEquals(1, container0.size());
	}

	@Test(timeout = 4000)
	public void testContainerInitialization_5() throws Throwable {
		Container container0 = new Container();
		ArrayList<Component> arrayList0 = container0.contents;
		assertNotNull(arrayList0);
	}

	@Test(timeout = 4000)
	public void testContainerCreation_2() throws Throwable {
		Container container0 = new Container();
		assertNotNull(container0);
	}

	@Test(timeout = 4000)
	public void testAddComponentToContainer_3() throws Throwable {
		Container container0 = new Container();
		ArrayList<Component> arrayList0 = container0.contents;
		Ingredient.State ingredient_State0 = Ingredient.State.Dry;
		Component component0 = new Component(0, ingredient_State0);
		arrayList0.add(component0);
		assertEquals(1, arrayList0.size());
	}

	@Test(timeout = 4000)
	public void testAddMultipleComponentsToContainer() throws Throwable {
		Container container0 = new Container();
		ArrayList<Component> arrayList0 = container0.contents;
		Ingredient.State ingredient_State0 = Ingredient.State.Dry;
		Component component0 = new Component(0, ingredient_State0);
		arrayList0.add(component0);
		arrayList0.add(component0);
		assertEquals(2, arrayList0.size());
	}

	@Test(timeout = 4000)
	public void testPopComponentFromContainer() throws Throwable {
		Container container0 = new Container();
		Ingredient.State ingredient_State0 = Ingredient.State.Dry;
		Component component0 = new Component(0, ingredient_State0);
		container0.contents.add(component0);
		container0.contents.add(component0);
		Component component1 = container0.pop();
		assertSame(component1, component0);
	}

	@Test(timeout = 4000)
	public void testContainerInitialization() throws Throwable {
		Container container0 = new Container();
		ArrayList<Component> arrayList0 = container0.contents;
		assertNotNull(arrayList0);
	}

	@Test(timeout = 4000)
	public void testAddComponentToContainer_4() throws Throwable {
		Container container0 = new Container();
		Ingredient.State ingredient_State0 = Ingredient.State.Dry;
		Component component0 = new Component(0, ingredient_State0);
		container0.contents.add(component0);
		int int0 = container0.size();
		assertEquals(1, int0);
	}

	@Test(timeout = 4000)
	public void testContainerPushNull_2() throws Throwable {
		Container container0 = new Container();
		container0.push((Component) null);
	}

	@Test(timeout = 4000)
	public void testContainerPopReturnsNull() throws Throwable {
		Container container0 = new Container();
		container0.push((Component) null);
		Component component0 = container0.pop();
		assertNull(component0);
	}

	@Test(timeout = 4000)
	public void Mtest09_pushComponent() throws Throwable {
		Container container0 = new Container();
		Ingredient.State ingredient_State0 = Ingredient.State.Dry;
		Component component0 = new Component(1, ingredient_State0);
		container0.push(component0);
	}

	@Test(timeout = 4000)
	public void Mtest09_popComponent() throws Throwable {
		Container container0 = new Container();
		Ingredient.State ingredient_State0 = Ingredient.State.Dry;
		Component component0 = new Component(1, ingredient_State0);
		container0.push(component0);
		Component component1 = container0.pop();
		assertSame(component1, component0);
	}

	@Test(timeout = 4000)
	public void Mtest10_step1() throws Throwable {
		Container container0 = new Container();
		ArrayList<Component> arrayList0 = container0.contents;
		Ingredient.State ingredient_State0 = Ingredient.State.Dry;
		Component component0 = new Component((-1), ingredient_State0);
		arrayList0.add(component0);
	}

	@Test(timeout = 4000)
	public void Mtest10_step2() throws Throwable {
		Container container0 = new Container();
		Component component0 = new Component((-1), Ingredient.State.Dry);
		container0.contents.add(component0);
		Component component1 = container0.pop();
		assertEquals(Ingredient.State.Dry, component1.getState());
	}

	@Test(timeout = 4000)
	public void testContainerPushNull() throws Throwable {
		Container container0 = new Container();
		container0.push((Component) null);
	}

	@Test(timeout = 4000)
	public void testContainerPeekNull() throws Throwable {
		Container container0 = new Container();
		container0.push((Component) null);
		Component component0 = container0.peek();
		assertNull(component0);
	}

	@Test(timeout = 4000)
	public void testAddComponentToContainer() throws Throwable {
		Container container0 = new Container();
		ArrayList<Component> arrayList0 = container0.contents;
		Ingredient.State ingredient_State0 = Ingredient.State.Dry;
		Component component0 = new Component(1, ingredient_State0);
		arrayList0.add(component0);
	}

	@Test(timeout = 4000)
	public void testPeekComponentValue() throws Throwable {
		Container container0 = new Container();
		Ingredient.State ingredient_State0 = Ingredient.State.Dry;
		Component component0 = new Component(1, ingredient_State0);
		container0.contents.add(component0);
		Component component1 = container0.peek();
		assertEquals(1, component1.getValue());
	}

	@Test(timeout = 4000)
	public void Mtest14_1() throws Throwable {
		Container container0 = new Container();
		ArrayList<Component> arrayList0 = container0.contents;
		Ingredient.State ingredient_State0 = Ingredient.State.Dry;
		Component component0 = new Component((-1), ingredient_State0);
		arrayList0.add(component0);
		assertNotNull(arrayList0);
	}

	@Test(timeout = 4000)
	public void Mtest14_2() throws Throwable {
		Container container0 = new Container();
		Ingredient.State ingredient_State0 = Ingredient.State.Dry;
		Component component0 = new Component((-1), ingredient_State0);
		container0.contents.add(component0);
		Component component1 = container0.peek();
		assertEquals((-1), component1.getValue());
	}

	@Test(timeout = 4000)
	public void Mtest15() throws Throwable {
		Container container0 = new Container();
		container0.contents = null;
		// Undeclared exception!
		try {
			container0.size();
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {
			//
			// no message in exception (getMessage() returned null)
			//
		}
	}

	@Test(timeout = 4000)
	public void Mtest16() throws Throwable {
		Container container0 = new Container();
		container0.contents = null;
		// Undeclared exception!
		try {
			container0.shuffle();
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {
			//
			// no message in exception (getMessage() returned null)
			//
		}
	}

	@Test(timeout = 4000)
	public void Mtest17() throws Throwable {
		Container container0 = new Container();
		container0.push((Component) null);
		// Undeclared exception!
		try {
			container0.serve();
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {
			//
			// no message in exception (getMessage() returned null)
			//
		}
	}

	@Test(timeout = 4000)
	public void Mtest18() throws Throwable {
		Container container0 = new Container();
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Component component0 = new Component((-1), ingredient_State0);
		container0.push(component0);
		// Undeclared exception!
		try {
			container0.serve();
			fail("Expecting exception: IllegalArgumentException");

		} catch (IllegalArgumentException e) {
			//
			// no message in exception (getMessage() returned null)
			//
		}
	}

	@Test(timeout = 4000)
	public void Mtest19() throws Throwable {
		Container container0 = new Container();
		container0.contents = null;
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Component component0 = new Component(0, ingredient_State0);
		// Undeclared exception!
		try {
			container0.push(component0);
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {
			//
			// no message in exception (getMessage() returned null)
			//
		}
	}

	@Test(timeout = 4000)
	public void Mtest20() throws Throwable {
		Container container0 = new Container();
		container0.contents = null;
		// Undeclared exception!
		try {
			container0.pop();
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {
			//
			// no message in exception (getMessage() returned null)
			//
		}
	}

	@Test(timeout = 4000)
	public void Mtest21() throws Throwable {
		Container container0 = new Container();
		container0.contents = null;
		// Undeclared exception!
		try {
			container0.peek();
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {
			//
			// no message in exception (getMessage() returned null)
			//
		}
	}

	@Test(timeout = 4000)
	public void Mtest22() throws Throwable {
		Container container0 = new Container();
		container0.contents = null;
		// Undeclared exception!
		try {
			container0.liquefy();
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {
			//
			// no message in exception (getMessage() returned null)
			//
		}
	}

	@Test(timeout = 4000)
	public void Mtest23() throws Throwable {
		Container container0 = new Container();
		// Undeclared exception!
		try {
			container0.combine((Container) null);
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {
			//
			// no message in exception (getMessage() returned null)
			//
		}
	}

	@Test(timeout = 4000)
	public void Mtest24() throws Throwable {
		Container container0 = null;
		try {
			container0 = new Container((Container) null);
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {
			//
			// no message in exception (getMessage() returned null)
			//
		}
	}

	@Test(timeout = 4000)
	public void testContainerCreation() throws Throwable {
		Container container0 = new Container();
		assertNotNull(container0);
	}

	@Test(timeout = 4000)
	public void testContainerAddComponent() throws Throwable {
		Container container0 = new Container();
		ArrayList<Component> arrayList0 = container0.contents;
		Ingredient.State ingredient_State0 = Ingredient.State.Dry;
		Component component0 = new Component(0, ingredient_State0);
		arrayList0.add(component0);
		assertTrue(arrayList0.contains(component0));
	}

	@Test(timeout = 4000)
	public void testContainerLiquefy() throws Throwable {
		Container container0 = new Container();
		ArrayList<Component> arrayList0 = container0.contents;
		Ingredient.State ingredient_State0 = Ingredient.State.Dry;
		Component component0 = new Component(0, ingredient_State0);
		arrayList0.add(component0);
		container0.liquefy();
		assertNotNull(container0);
	}

	@Test(timeout = 4000)
	public void testContainerServe() throws Throwable {
		Container container0 = new Container();
		ArrayList<Component> arrayList0 = container0.contents;
		Ingredient.State ingredient_State0 = Ingredient.State.Dry;
		Component component0 = new Component(0, ingredient_State0);
		arrayList0.add(component0);
		container0.liquefy();
		String string0 = container0.serve();
		assertEquals("\u0000", string0);
	}

	@Test(timeout = 4000)
	public void Mtest27() throws Throwable {
		Container container0 = new Container();
		try {
			container0.pop();
			fail("Expecting exception: ChefException");

		} catch (ChefException e) {
			//
			// Local error: Folded from empty container
			//
		}
	}

	@Test(timeout = 4000)
	public void Mtest28() throws Throwable {
		Container container0 = new Container();
		// Undeclared exception!
		try {
			container0.peek();
			fail("Expecting exception: ArrayIndexOutOfBoundsException");

		} catch (ArrayIndexOutOfBoundsException e) {
			//
			// no message in exception (getMessage() returned null)
			//
		}
	}

	@Test(timeout = 4000)
	public void Mtest30_part1() throws Throwable {
		Container container0 = new Container();
		Container container1 = new Container(container0);
		assertFalse(container1.equals((Object) container0));
	}

	@Test(timeout = 4000)
	public void Mtest30_part2() throws Throwable {
		Container container0 = new Container();
		Container container1 = new Container(container0);
		assertNotEquals(container1, container0);
	}

	@Test(timeout = 4000)
	public void testContainerShuffle() throws Throwable {
		Container container0 = new Container();
		container0.shuffle();
		// Assuming shuffle() should not alter size
		assertEquals(0, container0.size());
	}

	@Test(timeout = 4000)
	public void testContainerSize() throws Throwable {
		Container container0 = new Container();
		assertEquals(0, container0.size());
	}

	@Test(timeout = 4000)
	public void ptest00_part1() throws Throwable {
		Integer integer0 = new Integer(0);
		Ingredient.State ingredient_State0 = Ingredient.State.Dry;
		Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, (String) null);
		String string0 = ingredient0.getName();
		assertNull(string0);
	}

	@Test(timeout = 4000)
	public void ptest01_1() throws Throwable {
		Integer integer0 = new Integer(0);
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
		String string0 = ingredient0.getName();
		assertEquals("", string0);
	}

	@Test(timeout = 4000)
	public void ptest01_2() throws Throwable {
		Integer integer0 = new Integer(0);
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
		String string0 = ingredient0.getName();
		assertNotNull(string0);
	}

	@Test(timeout = 4000)
	public void ptest02_getAmount_returnsExpectedValue() throws Throwable {
		Integer integer0 = new Integer(0);
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
		int int0 = ingredient0.getAmount();
		assertEquals(0, int0);
	}

//	@Test(timeout = 4000)
//	public void testIngredientInitialization() throws Throwable {
//		Ingredient ingredient0 = new Ingredient("L");
//		int int0 = ingredient0.getAmount(); // This is the value to be verified
//		assertEquals(0, int0); // Assert here to verify initial value
//	}

	@Test(timeout = 4000)
	public void testIngredientAmountAfterSetting() throws Throwable {
		Ingredient ingredient0 = new Ingredient("L");
		ingredient0.setAmount(1);
		int int0 = ingredient0.getAmount();
		assertEquals(1, int0);
	}

	@Test(timeout = 4000)
	public void testIngredientSetAmount() throws Throwable {
		Ingredient ingredient0 = new Ingredient("s");
		ingredient0.setAmount(-1);
	}

	@Test(timeout = 4000)
	public void testIngredientGetAmount() throws Throwable {
		Ingredient ingredient0 = new Ingredient("s");
		ingredient0.setAmount(-1);
		int int0 = ingredient0.getAmount();
		assertEquals(-1, int0);
	}

	@Test(timeout = 4000)
	public void ptest05() throws Throwable {
		Ingredient ingredient0 = null;
		try {
			ingredient0 = new Ingredient((String) null);
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {
			//
			// no message in exception (getMessage() returned null)
			//
		}
	}

	@Test(timeout = 4000)
	public void ptest06() throws Throwable {
		Ingredient ingredient0 = null;
		try {
			ingredient0 = new Ingredient(" ");
			fail("Expecting exception: ArrayIndexOutOfBoundsException");

		} catch (ArrayIndexOutOfBoundsException e) {
			//
			// 0
			//
		}
	}

	@Test(timeout = 4000)
	public void testIngredientConstructor() throws Throwable {
		Ingredient ingredient0 = new Ingredient("A n");
	}

	@Test(timeout = 4000)
	public void testIngredientName() throws Throwable {
		Ingredient ingredient0 = new Ingredient("A n");
		assertEquals("A n", ingredient0.getName());
	}

	@Test(timeout = 4000)
	public void ptest08() throws Throwable {
		Ingredient ingredient0 = null;
		try {
			ingredient0 = new Ingredient("0 l");
			fail("Expecting exception: ChefException");

		} catch (Throwable e) {
			//
			// Ingredient wrongly formatted: '0 l' (ingredient name missing)
			//
		}
	}

	@Test(timeout = 4000)
	public void ptest09() throws Throwable {
		Ingredient ingredient0 = null;
		try {
			ingredient0 = new Ingredient("0 g");
			fail("Expecting exception: ChefException");

		} catch (Throwable e) {
			//
			// Ingredient wrongly formatted: '0 g' (ingredient name missing)
			//
		}
	}

	@Test(timeout = 4000)
	public void ptest11() throws Throwable {
		Ingredient ingredient0 = null;
		try {
			ingredient0 = new Ingredient("");
			fail("Expecting exception: NumberFormatException");

		} catch (NumberFormatException e) {
			//
			// For input string: \"\"
			//
		}
	}

	@Test(timeout = 4000)
	public void ptest12_step1() throws Throwable {
		Ingredient ingredient0 = new Ingredient("A");
		ingredient0.liquefy();
	}

	@Test(timeout = 4000)
	public void ptest12_step2() throws Throwable {
		Ingredient ingredient0 = new Ingredient("A");
		ingredient0.liquefy();
		assertEquals("A", ingredient0.getName());
	}

	@Test(timeout = 4000)
	public void ptest13_step1() throws Throwable {
		Integer integer0 = new Integer(0);
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
		ingredient0.dry();
		assertEquals(0, ingredient0.getAmount());
	}

	@Test(timeout = 4000)
	public void ptest13_step2() throws Throwable {
		Integer integer0 = new Integer(0);
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
		ingredient0.dry();
		assertEquals(0, ingredient0.getAmount());
	}

	@Test(timeout = 4000)
	public void ptest14() throws Throwable {
		Ingredient ingredient0 = new Ingredient("F");
		ingredient0.setState((Ingredient.State) null);
		ingredient0.getstate();
	}

	@Test(timeout = 4000)
	public void ptest15_ingredientCreation() throws Throwable {
		Ingredient ingredient0 = new Ingredient("F");
	}

	@Test(timeout = 4000)
	public void ptest15_getState() throws Throwable {
		Ingredient ingredient0 = new Ingredient("F");
		Ingredient.State ingredient_State0 = ingredient0.getstate();
	}

	@Test(timeout = 4000)
	public void ptest15_assertState() throws Throwable {
		Ingredient ingredient0 = new Ingredient("F");
		Ingredient.State ingredient_State0 = ingredient0.getstate();
		assertEquals(Ingredient.State.Dry, ingredient_State0);
	}

	@Test(timeout = 4000)
	public void ptest16_getName_ReturnsCorrectName() throws Throwable {
		Ingredient ingredient0 = new Ingredient("A");
		String string0 = ingredient0.getName();
		assertEquals("A", string0);
	}

	@Test(timeout = 4000)
	public void ptest17() throws Throwable {
		Ingredient ingredient0 = new Ingredient("L");
		// Undeclared exception!
		try {
			ingredient0.getAmount();
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {
			//
			// no message in exception (getMessage() returned null)
			//
		}
	}

	@Test(timeout = 4000)
	public void testCreateKitchen_2() throws Throwable {
		HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
		Recipe recipe0 = new Recipe("");
		recipe0.setMethod("X");
		Container[] containerArray0 = new Container[2];
		Container container0 = new Container();
		containerArray0[0] = container0;
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Component component0 = new Component(0, ingredient_State0);
		container0.push(component0);
		containerArray0[1] = container0;
		Kitchen kitchen0 = new Kitchen(hashMap0, recipe0, containerArray0, containerArray0);
		assertNotNull(kitchen0);
	}

	@Test(timeout = 4000)
	public void testCookSize() throws Throwable {
		HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
		Recipe recipe0 = new Recipe("");
		recipe0.setMethod("X");
		Container[] containerArray0 = new Container[2];
		Container container0 = new Container();
		containerArray0[0] = container0;
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Component component0 = new Component(0, ingredient_State0);
		container0.push(component0);
		containerArray0[1] = container0;
		Kitchen kitchen0 = new Kitchen(hashMap0, recipe0, containerArray0, containerArray0);
		Container container1 = kitchen0.cook();
		assertEquals(1, container1.size());
	}

	@Test(timeout = 4000)
	public void otest1() throws Throwable {
		HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
		Recipe recipe0 = new Recipe("");
		recipe0.setMethod("W");
		Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
		kitchen0.recipe = null;
		// Undeclared exception!
		try {
			kitchen0.cook();
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {
			//
			// no message in exception (getMessage() returned null)
			//
			// ("net.moocotest.Kitchen", e);
		}
	}

	@Test(timeout = 4000)
	public void testCreateEmptyHashMap() throws Throwable {
		HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
		assertNotNull(hashMap0);
	}

	// @Test(timeout = 4000)
	// public void testRecipeSetMethod() throws Throwable {
	// Recipe recipe0 = new Recipe("");
	// recipe0.setMethod("X");
	// assertEquals("X", recipe0.getMethod(0));
	// }

	@Test(timeout = 4000)
	public void testCreateContainerArray() throws Throwable {
		Container[] containerArray0 = new Container[2];
		Container container0 = new Container();
		containerArray0[0] = container0;
		containerArray0[1] = container0;
		assertNotNull(containerArray0);
		assertEquals(2, containerArray0.length);
	}

	@Test(timeout = 4000)
	public void testCreateKitchen() throws Throwable {
		HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
		Recipe recipe0 = new Recipe("");
		recipe0.setMethod("X");
		Container[] containerArray0 = new Container[2];
		Container container0 = new Container();
		containerArray0[0] = container0;
		containerArray0[1] = container0;
		Kitchen kitchen0 = new Kitchen(hashMap0, recipe0, containerArray0, containerArray0);
		assertNotNull(kitchen0);
	}

	@Test(timeout = 4000)
	public void testCookContainerSize() throws Throwable {
		HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
		Recipe recipe0 = new Recipe("");
		recipe0.setMethod("X");
		Container[] containerArray0 = new Container[2];
		Container container0 = new Container();
		containerArray0[0] = container0;
		containerArray0[1] = container0;
		Kitchen kitchen0 = new Kitchen(hashMap0, recipe0, containerArray0, containerArray0);
		Container container1 = kitchen0.cook();
		assertEquals(0, container1.size());
	}

	@Test(timeout = 4000)
	public void otest3() throws Throwable {
		HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
		Recipe recipe0 = new Recipe("");
		recipe0.setMethod("X");
		Container[] containerArray0 = new Container[2];
		Kitchen kitchen0 = null;
		try {
			kitchen0 = new Kitchen(hashMap0, recipe0, containerArray0, containerArray0);
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {
			//
			// no message in exception (getMessage() returned null)
			//
			// ("net.moocotest.Container", e);
		}
	}

	@Test(timeout = 4000)
	public void testHashMapInitialization() throws Throwable {
		HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
		assertNotNull(hashMap0);
	}

	@Test(timeout = 4000)
	public void testRecipeInitialization() throws Throwable {
		Recipe recipe0 = new Recipe("");
		assertNotNull(recipe0);
	}

//	@Test(timeout = 4000)
//	public void testSetMethod() throws Throwable {
//		Recipe recipe0 = new Recipe("");
//		recipe0.setMethod("s");
//		assertEquals("s", recipe0.getMethod(0));
//	}

//	@Test(timeout = 4000)
//	public void testKitchenInitialization() throws Throwable {
//		HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
//		Recipe recipe0 = new Recipe("");
//		Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
//		assertNotNull(kitchen0);
//	}

	// @Test(timeout = 4000)
	// public void testMixingbowlsAssignment() throws Throwable {
	// HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
	// Recipe recipe0 = new Recipe("");
	// Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
	// kitchen0.mixingbowls = kitchen0.bakingdishes;
	// assertEquals(kitchen0.bakingdishes, kitchen0.mixingbowls);
	// }

//	@Test(timeout = 4000)
//	public void testCookMethod() throws Throwable {
//		HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
//		Recipe recipe0 = new Recipe("");
//		Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
//		kitchen0.mixingbowls = kitchen0.bakingdishes;
//		Container container0 = kitchen0.cook();
//		assertNull(container0);
//	}

	@Test(timeout = 4000)
	public void otest5() throws Throwable {
		HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
		Recipe recipe0 = new Recipe("");
		Kitchen kitchen0 = null;
		try {
			kitchen0 = new Kitchen(hashMap0, recipe0);
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {
			//
			// no message in exception (getMessage() returned null)
			//
			// ("net.moocotest.Kitchen", e);
		}
	}

	@Test(timeout = 4000)
	public void ttest0() throws Throwable {
		Method method0 = null;
		try {
			method0 = new Method((String) null, 0);
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {
			//
			// no message in exception (getMessage() returned null)
			//
		}
	}

	@Test(timeout = 4000)
	public void ttest1() throws Throwable {
		Method method0 = null;
		try {
			method0 = new Method("", 0);
			fail("Expecting exception: ChefException");

		} catch (Throwable e) {
			//
			// Method error, step 1: (Unsupported method found!)
			//
		}
	}

	@Test(timeout = 4000)
	public void itest00() throws Throwable {
		Recipe recipe0 = new Recipe("");
		recipe0.setIngredients("A");
		// Undeclared exception!
		try {
			recipe0.setIngredientValue("", 0);
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {
			//
			// no message in exception (getMessage() returned null)
			//
			// ("net.moocitest.Recipe", e);
		}
	}

	@Test(timeout = 4000)
	public void testRecipeIngredientsInitialization() throws Throwable {
		Recipe recipe0 = new Recipe("");
		recipe0.setIngredients("v");
		HashMap<String, Ingredient> hashMap0 = recipe0.getIngredients();
		assertTrue(hashMap0.isEmpty());
	}

	@Test(timeout = 4000)
	public void testRecipeSetIngredients() throws Throwable {
		Recipe recipe0 = new Recipe("");
		recipe0.setIngredients("v");
		HashMap<String, Ingredient> hashMap0 = recipe0.getIngredients();
		assertTrue(hashMap0.isEmpty());
	}

	@Test(timeout = 4000)
	public void itest06() throws Throwable {
		Recipe recipe0 = new Recipe("");
		// Undeclared exception!
		try {
			recipe0.setServes("gas mark");
			fail("Expecting exception: NumberFormatException");

		} catch (NumberFormatException e) {
			//
			// For input string: \"\"
			//
			// ("java.lang.NumberFormatException", e);
		}
	}

	@Test(timeout = 4000)
	public void itest07() throws Throwable {
		Recipe recipe0 = new Recipe("");
		// Undeclared exception!
		try {
			recipe0.setServes((String) null);
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {
			//
			// no message in exception (getMessage() returned null)
			//
			// ("net.moocitest.Recipe", e);
		}
	}

	@Test(timeout = 4000)
	public void itest08() throws Throwable {
		Recipe recipe0 = new Recipe("");
		// Undeclared exception!
		try {
			recipe0.setOvenTemp("   t");
			fail("Expecting exception: NumberFormatException");

		} catch (NumberFormatException e) {
			//
			// For input string: \"t\"
			//
			// ("java.lang.NumberFormatException", e);
		}
	}

	@Test(timeout = 4000)
	public void itest09() throws Throwable {
		Recipe recipe0 = new Recipe((String) null);
		// Undeclared exception!
		try {
			recipe0.setOvenTemp((String) null);
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {
			//
			// no message in exception (getMessage() returned null)
			//
			// ("net.moocitest.Recipe", e);
		}
	}

	@Test(timeout = 4000)
	public void itest10() throws Throwable {
		Recipe recipe0 = new Recipe("");
		// Undeclared exception!
		try {
			recipe0.setOvenTemp("");
			fail("Expecting exception: ArrayIndexOutOfBoundsException");

		} catch (ArrayIndexOutOfBoundsException e) {
			//
			// 3
			//
			// ("net.moocitest.Recipe", e);
		}
	}

	@Test(timeout = 4000)
	public void itest11() throws Throwable {
		Recipe recipe0 = new Recipe("");
		// Undeclared exception!
		try {
			recipe0.setMethod("");
			fail("Expecting exception: NoSuchElementException");

		} catch (NoSuchElementException e) {
			//
			// no message in exception (getMessage() returned null)
			//
			// ("java.util.Scanner", e);
		}
	}

	@Test(timeout = 4000)
	public void itest12() throws Throwable {
		Recipe recipe0 = new Recipe("");
		// Undeclared exception!
		try {
			recipe0.setMethod((String) null);
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {
			//
			// no message in exception (getMessage() returned null)
			//
			// ("net.moocitest.Recipe", e);
		}
	}

	@Test(timeout = 4000)
	public void itest13() throws Throwable {
		Recipe recipe0 = new Recipe("");
		// Undeclared exception!
		try {
			recipe0.setIngredients("");
			fail("Expecting exception: NoSuchElementException");

		} catch (NoSuchElementException e) {
			//
			// no message in exception (getMessage() returned null)
			//
			// ("java.util.Scanner", e);
		}
	}

	@Test(timeout = 4000)
	public void itest14() throws Throwable {
		Recipe recipe0 = new Recipe((String) null);
		// Undeclared exception!
		try {
			recipe0.setIngredients((String) null);
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {
			//
			// no message in exception (getMessage() returned null)
			//
		}
	}

	@Test(timeout = 4000)
	public void itest15() throws Throwable {
		Recipe recipe0 = new Recipe("");
		// Undeclared exception!
		try {
			recipe0.setCookingTime("  (");
			fail("Expecting exception: NumberFormatException");

		} catch (NumberFormatException e) {
			//
			// For input string: \"(\"
			//
			// ("java.lang.NumberFormatException", e);
		}
	}

	@Test(timeout = 4000)
	public void itest16() throws Throwable {
		Recipe recipe0 = new Recipe((String) null);
		// Undeclared exception!
		try {
			recipe0.setCookingTime((String) null);
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {
			//
			// no message in exception (getMessage() returned null)
			//
			// ("net.moocitest.Recipe", e);
		}
	}

	@Test(timeout = 4000)
	public void itest17() throws Throwable {
		Recipe recipe0 = new Recipe("");
		recipe0.setMethod("g");
		// Undeclared exception!
		try {
			recipe0.getMethod(0);
			fail("Expecting exception: IndexOutOfBoundsException");

		} catch (IndexOutOfBoundsException e) {
			//
			// Index: 0, Size: 0
			//
			// ("java.util.ArrayList", e);
		}
	}

	@Test(timeout = 4000)
	public void itest18() throws Throwable {
		Recipe recipe0 = new Recipe("");
		recipe0.setMethod("g");
		// Undeclared exception!
		try {
			recipe0.getMethod((-1));
			fail("Expecting exception: ArrayIndexOutOfBoundsException");

		} catch (ArrayIndexOutOfBoundsException e) {
			//
			// no message in exception (getMessage() returned null)
			//
		}
	}

	@Test(timeout = 4000)
	public void itest19() throws Throwable {
		Recipe recipe0 = new Recipe((String) null);
		try {
			recipe0.setMethod("B.d");
			fail("Expecting exception: ChefException");

		} catch (ChefException e) {
			//
			// Method error, step 1: d. (Unsupported method found!)
			//
			// ("net.moocitest.Method", e);
		}
	}

	@Test(timeout = 4000)
	public void itest20() throws Throwable {
		Recipe recipe0 = new Recipe("");
		// Undeclared exception!
		try {
			recipe0.getMethod(0);
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {
			//
			// no message in exception (getMessage() returned null)
			//
			// ("net.moocitest.Recipe", e);
		}
	}

	@Test(timeout = 4000)
	public void itest21() throws Throwable {
		Recipe recipe0 = new Recipe("");
		// Undeclared exception!
		try {
			recipe0.setCookingTime("");
			fail("Expecting exception: ArrayIndexOutOfBoundsException");

		} catch (ArrayIndexOutOfBoundsException e) {
			//
			// 2
			//
			// ("net.moocitest.Recipe", e);
		}
	}

//	@Test(timeout = 4000)
//	public void testRecipeGetIngredientsNotNull() throws Throwable {
//		Recipe recipe0 = new Recipe("");
//		HashMap<String, Ingredient> hashMap0 = recipe0.getIngredients();
//		assertNotNull(hashMap0);
//	}

//	@Test(timeout = 4000)
//	public void testRecipeGetIngredientsEmpty() throws Throwable {
//		Recipe recipe0 = new Recipe("");
//		HashMap<String, Ingredient> hashMap0 = recipe0.getIngredients();
//		assertTrue(hashMap0.isEmpty());
//	}

	@Test(timeout = 4000)
	public void itest23() throws Throwable {
		Recipe recipe0 = new Recipe("");
		// Undeclared exception!
		try {
			recipe0.setServes("");
			fail("Expecting exception: StringIndexOutOfBoundsException");

		} catch (StringIndexOutOfBoundsException e) {
		}
	}

	@Test(timeout = 4000)
	public void testRecipeGetServes() throws Throwable {
		Recipe recipe0 = new Recipe("");
		int int0 = recipe0.getServes();
		assertEquals(0, int0);
	}

	@Test(timeout = 4000)
	public void itest26() throws Throwable {
		Recipe recipe0 = new Recipe("");
		// Undeclared exception!
		try {
			recipe0.getIngredientValue("");
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {
			//
			// no message in exception (getMessage() returned null)
			//
			// ("net.moocitest.Recipe", e);
		}
	}

	@Test(timeout = 4000)
	public void itest28_setComments_emptyString() throws Throwable {
		Recipe recipe0 = new Recipe("");
		recipe0.setComments("");
		// no assertion here
	}

	@Test(timeout = 4000)
	public void itest28_getTitle_emptyString() throws Throwable {
		Recipe recipe0 = new Recipe("");
		recipe0.setComments("");
		assertEquals("", recipe0.getTitle());
	}

	@Test(timeout = 4000)
	public void test80_setupHashMap() throws Throwable {
		HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
		// additional setup code here if needed
	}

	@Test(timeout = 4000)
	public void test80_setupRecipe() throws Throwable {
		Recipe recipe0 = new Recipe("");
		recipe0.setMethod("9");
		// additional setup code here if needed
	}

	@Test(timeout = 4000)
	public void test80_setupContainers() throws Throwable {
		Container[] containerArray0 = new Container[2];
		Container container0 = new Container();
		containerArray0[0] = container0;
		Container container1 = new Container();
		containerArray0[1] = container1;
		// additional setup code here if needed
	}

	@Test(timeout = 4000)
	public void test80_setupComponent() throws Throwable {
		Ingredient.State ingredient_State0 = Ingredient.State.Dry;
		Component component0 = new Component(0, ingredient_State0);
		Container container0 = new Container();
		container0.push(component0);
		// additional setup code here if needed
	}

	@Test(timeout = 4000)
	public void test80_kitchenCook() throws Throwable {
		HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
		Recipe recipe0 = new Recipe("");
		recipe0.setMethod("9");
		Container[] containerArray0 = new Container[2];
		Container container0 = new Container();
		containerArray0[0] = container0;
		Container container1 = new Container();
		containerArray0[1] = container1;
		Ingredient.State ingredient_State0 = Ingredient.State.Dry;
		Component component0 = new Component(0, ingredient_State0);
		container0.push(component0);
		Kitchen kitchen0 = new Kitchen(hashMap0, recipe0, containerArray0, containerArray0);
		Container result = kitchen0.cook();
		assertFalse(result.equals((Object) container0));
	}

	@Test(timeout = 4000)
	public void test81() throws Throwable {
		HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
		Recipe recipe0 = new Recipe("");
		recipe0.setMethod("b");
		Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
		kitchen0.recipe = null;
		// Undeclared exception!
		try {
			kitchen0.cook();
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {
			//
			// no message in exception (getMessage() returned null)
			//
		}
	}

	@Test(timeout = 4000)
	public void test82_initialization() throws Throwable {
		HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
		Recipe recipe0 = new Recipe("");
		recipe0.setMethod("d");
		Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
		Container[] containerArray0 = new Container[0];
		kitchen0.mixingbowls = containerArray0;
		Container container0 = kitchen0.cook();
		assertNull(container0);
	}

	@Test(timeout = 4000)
	public void test82_hashMapInitialization() throws Throwable {
		HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
		assertNotNull(hashMap0);
	}

	@Test(timeout = 4000)
	public void test82_recipeInitialization() throws Throwable {
		Recipe recipe0 = new Recipe("");
		assertNotNull(recipe0);
	}

	@Test(timeout = 4000)
	public void test82_kitchenInitialization() throws Throwable {
		HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
		Recipe recipe0 = new Recipe("");
		recipe0.setMethod("d");
		Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
		assertNotNull(kitchen0);
	}

	@Test(timeout = 4000)
	public void test82_mixingbowlsInitialization() throws Throwable {
		HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
		Recipe recipe0 = new Recipe("");
		recipe0.setMethod("d");
		Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
		Container[] containerArray0 = new Container[0];
		kitchen0.mixingbowls = containerArray0;
		assertNotNull(kitchen0.mixingbowls);
	}

	@Test(timeout = 4000)
	public void test82_cookMethod() throws Throwable {
		HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
		Recipe recipe0 = new Recipe("");
		recipe0.setMethod("d");
		Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
		Container[] containerArray0 = new Container[0];
		kitchen0.mixingbowls = containerArray0;
		Container container0 = kitchen0.cook();
		assertNull(container0);
	}

	@Test(timeout = 4000)
	public void test83() throws Throwable {
		HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
		Recipe recipe0 = new Recipe("");
		Container[] containerArray0 = new Container[2];
		recipe0.setMethod("9");
		Kitchen kitchen0 = null;
		try {
			kitchen0 = new Kitchen(hashMap0, recipe0, containerArray0, containerArray0);
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {
			//
			// no message in exception (getMessage() returned null)
			//
		}
	}

	@Test(timeout = 4000)
	public void test84_1() throws Throwable {
		HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
		assertNotNull(hashMap0);
	}

	@Test(timeout = 4000)
	public void test84_2() throws Throwable {
		Recipe recipe0 = new Recipe("");
		assertNotNull(recipe0);
	}

	// @Test(timeout = 4000)
	// public void test84_3() throws Throwable {
	// Recipe recipe0 = new Recipe("");
	// recipe0.setMethod("b");
	// assertEquals("b", recipe0.getMethod(0));
	// }

	@Test(timeout = 4000)
	public void test84_4() throws Throwable {
		HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
		Recipe recipe0 = new Recipe("");
		recipe0.setMethod("b");
		Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
		assertNotNull(kitchen0);
	}

	@Test(timeout = 4000)
	public void test84_5() throws Throwable {
		HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
		Recipe recipe0 = new Recipe("");
		recipe0.setMethod("b");
		Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
		Container container0 = kitchen0.cook();
		assertNotNull(container0);
	}

	@Test(timeout = 4000)
	public void test84_6() throws Throwable {
		HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
		Recipe recipe0 = new Recipe("");
		recipe0.setMethod("b");
		Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
		Container container0 = kitchen0.cook();
		assertEquals(0, container0.size());
	}

	@Test(timeout = 4000)
	public void test85() throws Throwable {
		HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
		Recipe recipe0 = new Recipe("");
		Kitchen kitchen0 = null;
		try {
			kitchen0 = new Kitchen(hashMap0, recipe0);
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {
			//
			// no message in exception (getMessage() returned null)
			//
		}
	}
}
